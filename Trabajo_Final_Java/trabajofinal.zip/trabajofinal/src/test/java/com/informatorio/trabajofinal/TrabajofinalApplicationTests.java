package com.informatorio.trabajofinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajofinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
