package com.informatorio.trabajofinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabajofinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabajofinalApplication.class, args);
	}

}
